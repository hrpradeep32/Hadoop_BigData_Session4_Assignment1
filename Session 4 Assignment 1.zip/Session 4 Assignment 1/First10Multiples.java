package Package1;

import java.util.Scanner;

public class First10Multiples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number you want to multiply for first 10: ");
		int i = sc.nextInt();
		
		for (int x = 1 ; x<=10 ; x++ )
		{
			System.out.println(i + "*" + x +"=" +i*x);
		}
		
	}

}

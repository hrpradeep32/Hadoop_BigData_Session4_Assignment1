/* Write a java code with the class named �acad� and a method �main�. Hard Code the program with two integers and 
 * print the sum of those two.
 */


package Package1;

public class acad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			int a = 10;
			int b = 20;
			int c = a+b;
			System.out.println("Sum of two integers:" +c);
	}

}

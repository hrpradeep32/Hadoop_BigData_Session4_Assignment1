/*3) Write a program with method name sum() that accepts two parameters from user and print the sum of 
two numbers. Output format should be as: First number is:  Second number is:   Sum is:*/

package Package1;

import java.util.Scanner;

public class SumMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		sum();
		
	}

	public static void sum(){
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the First number: " );
		int a = sc.nextInt();
		
		System.out.println("Enter the Second number: " );
		int b = sc.nextInt();
		
		int c = a + b;
		
		System.out.println("Sum is: " +c);
		
	}
}

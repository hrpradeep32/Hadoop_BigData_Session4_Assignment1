/*3) Write a program with method name sum() that accepts two parameters from user and print the sum of 
two numbers. Output format should be as: First number is:  Second number is:   Sum is:*/

package Package1;

public class ArrayDescending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array={10,5,30,1,60,95,2};
		int[] descendingArray=new int[array.length];
		int large=0;
		int prevLarge=999999999;
		for(int i=0;i<array.length;i++)
		{
			for(int j=0;j<array.length;j++)
			{
				if(array[j]>large&&array[j]<prevLarge)
					large=array[j];
			}
			descendingArray[i]=large;
			prevLarge=large;
			large=0;
		}
		System.out.println("array in descending order: ");
		for(int i=0;i<descendingArray.length;i++)
		{
			System.out.println(descendingArray[i]);
		}
	}

}

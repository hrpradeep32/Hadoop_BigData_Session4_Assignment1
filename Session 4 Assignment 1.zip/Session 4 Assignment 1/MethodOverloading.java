package Package1;

public class MethodOverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

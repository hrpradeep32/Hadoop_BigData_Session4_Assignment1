/* Write a java code with the class named �acad� and a method �main�. inputs are provided by the user at runtime 
 * and the output is printed ---- print the sum of those two.*/


package Package1;

import java.util.Scanner;

public class acad_runtime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub			
			
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter the value for a: ");
			int a=sc.nextInt();

			System.out.println("Enter the value for b: ");
			int b=sc.nextInt();
			
			int c = a+b;
			
			System.out.println("Sum of two integers:" +c);
	}

}

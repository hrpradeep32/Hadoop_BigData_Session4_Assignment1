/*4) Write a program to accepts two numbers from stdin and find all the odd as well as even
numbers present in between them.
*/


/*4) Write a program to accepts two numbers from stdin and find all the odd as well as even
numbers present in between them.
*/



package Package1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		int start=sc.nextInt();
		int end=sc.nextInt();
		List<Integer> odds=new ArrayList<Integer>();
		List<Integer> evens=new ArrayList<Integer>();
		if(start>end)
		{
			System.out.println("invalid range");
			System.exit(0);
		}
		for(int i=start;i<=end;i++)
		{
			if(i%2==0)
				evens.add(i);
			else
				odds.add(i);
		}
		System.out.println("all the odd numbers within the range is: ");
		for(int i=0;i<odds.size();i++)
		{
			System.out.println(odds.get(i));
		}
		System.out.println("all the even numbers within the range is: ");
		for(int i=0;i<evens.size();i++)
		{
			System.out.println(evens.get(i));
		}
	}

}
